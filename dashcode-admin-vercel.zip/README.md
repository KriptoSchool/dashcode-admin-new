# Investment Management System

A comprehensive multi-level marketing investment platform built with Next.js 15, Supabase, and Shadcn UI.

## Features

### 🏦 Investment Tiers

**Standard Plans:**
- **Type A1**: RM25,000 - 2.0% quarterly (8.0% yearly)
- **Type A**: RM50,000 - 3.0% quarterly (12.0% yearly)
- **Type B**: RM100,000-RM150,000 - 3.5% quarterly (14.0% yearly)
- **Type C**: RM200,000-RM450,000 - 3.6% quarterly (14.5% yearly)
- **Type D**: RM500,000-RM950,000 - 3.9% quarterly (15.5% yearly)
- **Type E**: RM1.0M+ - 4.1% quarterly (16.5% yearly)

**Exclusive Plans:**
- 2.5% quarterly (11.0% yearly)
- 3.5% quarterly (14.2% yearly)
- 4.0% quarterly (15.5% yearly)
- 4.3% quarterly (17.0% yearly)
- 5.0% quarterly (19.5% yearly)
- 5.5% quarterly (22.0% yearly)

### 👥 Agent Hierarchy System

1. **VC Consultant** → 1.5% goes to nearest Business Dev
2. **Business Dev** → 0.8% goes to nearest Strategy Partner (SP must have ≥3 direct BDs)
3. **Strategy Partner** → 0.5% goes to nearest General Manager (GM must have ≥3 direct SPs)
4. **General Manager** → Top level

### 💰 Commission Structure

- **Personal Sale**: 2% for passive payments
- **One-off**: 10% commission
- **Hierarchical**: Automatic percentage distribution based on agent levels

### 🔐 Role-Based Access Control

- **Agents**: View own commissions, investors, and subordinate consultants
- **Investors**: View investment details and dividend calculations
- **Unique IDs**: Each agent has a searchable ID for easy identification

## Tech Stack

- **Frontend**: Next.js 15 with App Router
- **Backend**: Supabase (PostgreSQL + Auth + Real-time)
- **UI**: Shadcn UI + Tailwind CSS
- **Language**: TypeScript
- **Authentication**: Supabase Auth with Row Level Security

## Setup Instructions

### 1. Prerequisites

- Node.js 18+ installed
- Supabase account

### 2. Supabase Setup

1. Create a new Supabase project at [supabase.com](https://supabase.com)
2. Go to SQL Editor and run the schema from `supabase-schema.sql`
3. Get your project URL and anon key from Settings → API

### 3. Environment Variables

Update `.env.local` with your Supabase credentials:

```env
NEXT_PUBLIC_SUPABASE_URL=your_supabase_project_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_role_key
```

### 4. Install Dependencies

```bash
npm install
```

### 5. Run Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## Project Structure

```
src/
├── app/
│   ├── auth/
│   │   ├── signin/                 # Sign-in page
│   │   └── register/
│   │       ├── consultant/         # Agent registration
│   │       └── investor/           # Investor registration
│   └── dashboard/
│       ├── agent/                  # Agent dashboard
│       └── investor/               # Investor dashboard
├── components/ui/                  # Shadcn UI components
└── lib/
    └── supabase.ts                 # Supabase client & types
```

## Database Schema

### Core Tables

- **users**: Extends Supabase auth.users
- **agents**: Agent information and hierarchy
- **investors**: Investor details and KYC data
- **investments**: Investment records
- **commissions**: Commission calculations
- **dividends**: Dividend payments
- **investment_tiers**: Tier configurations

### Key Features

- **Row Level Security**: Users can only access their own data
- **Automatic Triggers**: Commission calculation on new investments
- **Hierarchical Queries**: Agent hierarchy traversal
- **Real-time Updates**: Live data synchronization

## User Flows

### Agent Registration
1. Fill consultant application form
2. Email verification
3. Admin approval (optional)
4. Access to agent dashboard

### Investor Registration
1. Enter consultant/agent ID
2. Complete investor form with KYC details
3. Email verification
4. Investment tier selection
5. Access to investor dashboard

### Commission Calculation
1. Investor makes investment
2. System automatically calculates:
   - 2% passive commission for direct agent
   - 10% one-off commission for direct agent
   - Hierarchical commissions based on agent levels
3. Commissions appear in agent dashboard

## Deployment

### Option 1: Vercel (Recommended)

1. Push code to GitHub
2. Connect repository to Vercel
3. Add environment variables
4. Deploy automatically

### Option 2: Custom Domain

1. Build the application:
   ```bash
   npm run build
   ```

2. Start production server:
   ```bash
   npm start
   ```

3. Configure your domain DNS to point to your server
4. Set up SSL certificate

## Security Features

- **Row Level Security**: Database-level access control
- **JWT Authentication**: Secure token-based auth
- **Input Validation**: Form validation and sanitization
- **HTTPS Only**: Secure data transmission
- **Environment Variables**: Sensitive data protection

## Support

For technical support or questions about the investment platform:

1. Check the database schema in `supabase-schema.sql`
2. Review the Supabase configuration in `src/lib/supabase.ts`
3. Test the authentication flow with the registration forms

## License

This project is proprietary software for investment management purposes.